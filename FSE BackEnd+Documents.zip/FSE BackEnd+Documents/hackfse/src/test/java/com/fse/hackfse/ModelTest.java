package com.fse.hackfse;

import org.junit.Test;

import com.fse.hackfse.Response.MemberResponse;
import com.fse.hackfse.Response.ResponseHandler;
import com.fse.hackfse.Response.Tasks;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class ModelTest {
	@Test
	public void validateSettersAndGetters() {
		// Defines which POJO will be put under test
		PojoClass personPojo = PojoClassFactory.getPojoClass(MemberResponse.class);
		PojoClass personPojo1 = PojoClassFactory.getPojoClass(Tasks.class);
		PojoClass personPoj21 = PojoClassFactory.getPojoClass(ResponseHandler.class);
		PojoClass personPoj3 = PojoClassFactory.getPojoClass(TaskDetail.class);
		PojoClass personPoj4 = PojoClassFactory.getPojoClass(MemberDetail.class);
		Validator validator = ValidatorBuilder.create()
				// Ensures that every field has a Getter/Setter
				.with(new GetterMustExistRule()).with(new SetterMustExistRule())
				// Ensures that the Getters and Setters Behave as expected
				.with(new SetterTester()).with(new GetterTester()).build();
		// Start the Test
		validator.validate(personPojo);
		validator.validate(personPoj3);
		validator.validate(personPoj4);
		validator.validate(personPoj21);
		validator.validate(personPojo1);
	}
}
