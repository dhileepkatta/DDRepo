package com.fse.hackfse.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fse.hackfse.model.Member;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.fse.hackfse.service.KafkaSender;
import com.fse.hackfse.service.MemberService;

@RunWith(SpringJUnit4ClassRunner.class)
public class MemberControllerTest {
	
	@Mock
	   private MemberService service;
	
	@Mock
	   private KafkaSender sender;
	
	@InjectMocks
	 MemberController controller;

	@Before
	public void setup() {
		
	}
	
	@Test
	public void getAssignedTasks() {
		Member member= new Member();
		member.setMemberId(1);
		MemberDetail memberDetail = new MemberDetail();
		
		memberDetail.setProjectEndDate(Date.valueOf("2023-01-01"));
		List<TaskDetail> taskDetail = new ArrayList();
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(memberDetail);
		
		Mockito.when(service.getAllTasks(Mockito.anyInt())).thenReturn(taskDetail);
		controller.getAssignedTasks(2);
		
	}
	
	@Test
	public void getAssignedTasks2() {
		Member member= new Member();
		member.setMemberId(1);
		MemberDetail memberDetail = new MemberDetail();
		
		memberDetail.setProjectEndDate(Date.valueOf("2023-01-01"));
		List<TaskDetail> taskDetail = new ArrayList();
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(null);
		
		controller.getAssignedTasks(2);
		
	}

}
