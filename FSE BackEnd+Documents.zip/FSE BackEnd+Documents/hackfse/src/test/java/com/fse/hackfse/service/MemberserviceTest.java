package com.fse.hackfse.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.fse.hackfse.repository.MemberRepository;
import com.fse.hackfse.repository.TaskRepository;

@RunWith(SpringJUnit4ClassRunner.class)
public class MemberserviceTest {
	
	@InjectMocks
	    MemberService service;
	@Mock
	 private TaskRepository taskRepository;
	
	
	@Mock
	private MemberRepository memberRepository;

	@Before
	public void setup() {
		
	}
	
	
	@Test
	public void saveMemberDetails() {
		MemberDetail member = new MemberDetail();
		service.saveMemberDetails(member);
	}
	
	@Test
	public void getAllMembers() {
		service.getAllMembers();
	}
	
	@Test
	public void getAllTasks() {
		service.getAllTasks(1);
	}
	
	@Test
	public void assignTask() {
		TaskDetail task = new TaskDetail();
		service.assignTask(task);
	}

	@Test
	public void findByMemberId() {
		service.findByMemberId(1);
	}
	
	@Test
	public void getMemberById() {
		service.getMemberById(1);
	}
	
	@Test
	public void updateAllocation() {
		service.updateAllocation(Mockito.anyInt(),Mockito.anyDouble());
	}


}
