package com.fse.hackfse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackfseApplicationTests {

	@Test
	void contextLoads() {
	}

}
