package com.fse.hackfse.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fse.hackfse.model.Member;
import com.fse.hackfse.model.Task;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.service.KafkaSender;
import com.fse.hackfse.service.MemberService;


@RunWith(SpringJUnit4ClassRunner.class)
public class ManagerControllerTest {
	
	

	private MockMvc mockMvc;
	
	@Mock
	   private MemberService service;
	
	@Mock
	   private KafkaSender sender;
	
	@InjectMocks
	 ManagerController controller;

	@Before
	public void setup() {
		
	}
	
	@Test
	public void saveMemberTest() {
		Member member = new Member();
		member.setExperience(10);
		 String str="2021-03-31";  
		    Date date=Date.valueOf(str);
		member.setSkills("test,test1,test2");
		member.setMemberName("test");
		member.setAdditionalDesc("test");
		member.setPercentage(2.2);
		member.setProjectEndDate(date);
		member.setProjectStartDate(Date.valueOf("2020-01-01"));
		member.setMemberId(1);
		Mockito.when(service.findByMemberId(Mockito.anyInt())).thenReturn(false);
		controller.saveMember(member);
	}
	
	@Test
	public void saveMemberTest1() {
		Member member = new Member();
		member.setExperience(2);
		 String str="2015-03-31";  
		    Date date=Date.valueOf(str);
		member.setSkills("test,test1");
		member.setProjectEndDate(date);
		member.setProjectStartDate(Date.valueOf("2020-01-01"));
		member.setMemberId(1);
		Mockito.when(service.findByMemberId(Mockito.anyInt())).thenReturn(true);
		controller.saveMember(member);
	}
	
	@Test
	public void getAllMembersTest1() {
		List<MemberDetail> memberList = new ArrayList();
		MemberDetail memberDetail= new MemberDetail();
		memberDetail.setMemberId(12);
		memberList.add(memberDetail);
		Mockito.when(service.getAllMembers()).thenReturn(memberList);		
		controller.getAllMembers();
	}
	
	@Test
	public void getAllMembersTest2() {
		List<MemberDetail> memberList = new ArrayList();
		MemberDetail memberDetail= new MemberDetail();
		memberDetail.setMemberId(12);
		memberList.add(memberDetail);
		Mockito.when(service.getAllMembers()).thenReturn(null);		
		controller.getAllMembers();
	}
	
	@Test
	public void assignTask() {
		Task task = new Task();
		task.setMemberId(1);
		task.setTaskId(2);
		task.setTaskName("test");
		task.setDeliverables("test");
		task.setTaskEndDate(Date.valueOf("2019-03-01"));
		task.setTaskStartDate(Date.valueOf("2019-01-01"));
		MemberDetail detail= new MemberDetail();
		detail.setProjectEndDate(Date.valueOf("2022-01-01"));
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(detail);
		controller.assignTask(task);
	}
	
	
	
	@Test
	public void assignTaskTest2() {
		Task task = new Task();
		task.setMemberId(1);
		task.setTaskEndDate(Date.valueOf("2019-01-01"));
		task.setTaskStartDate(Date.valueOf("2019-03-01"));
		MemberDetail detail= new MemberDetail();
		detail.setProjectEndDate(Date.valueOf("2018-01-01"));
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(detail);
		controller.assignTask(task);
	}
	
	@Test
	public void UpdateAllocation() {
		Member member= new Member();
		member.setMemberId(1);
		MemberDetail memberDetail = new MemberDetail();
		
		memberDetail.setProjectEndDate(Date.valueOf("2019-01-01"));
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(memberDetail);
		controller.UpdateAllocation(member);
		
	}
	
	@Test
	public void UpdateAllocationTest2() {
		Member member= new Member();
		member.setMemberId(1);
		MemberDetail memberDetail = new MemberDetail();
		
		memberDetail.setProjectEndDate(Date.valueOf("2023-01-01"));
		Mockito.when(service.getMemberById(Mockito.anyInt())).thenReturn(memberDetail);
		controller.UpdateAllocation(member);
		
	}

}
