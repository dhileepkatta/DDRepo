package com.fse.hackfse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.fse.hackfse.repository.MemberRepository;
import com.fse.hackfse.repository.TaskRepository;

@Service
public class MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Autowired
	private TaskRepository taskRepository;

	/**
	 * method to saveMemberDetails
	 * 
	 * @param member
	 * @return
	 */
	public MemberDetail saveMemberDetails(MemberDetail member) {

		return memberRepository.save(member);
	}

	/**
	 * method to getAllMembers
	 * 
	 * @return
	 */
	public List<MemberDetail> getAllMembers() {

		return memberRepository.findAll(Sort.by(Sort.Direction.DESC, "experience"));
	}

	/**
	 * method to getAllTasks
	 * 
	 * @param memberId
	 * @return
	 */
	public List<TaskDetail> getAllTasks(int memberId) {
		return taskRepository.findByMemberId(memberId);
	}

	/**
	 * method to assignTask
	 * 
	 * @param task
	 * @return
	 */
	public TaskDetail assignTask(TaskDetail task) {

		return taskRepository.save(task);
	}

	/**
	 * method to findByMemberId
	 * 
	 * @param memberId
	 * @return
	 */
	public boolean findByMemberId(int memberId) {
		return memberRepository.memberIdExist(memberId);
	}

	/**
	 * method to getMemberById
	 * 
	 * @param memberid
	 * @return
	 */
	public MemberDetail getMemberById(int memberid) {
		MemberDetail member = memberRepository.findByMemberId(memberid);
		return member;

	}

	/**
	 * method to updateAllocation
	 * 
	 * @param memberId
	 * @param percentage
	 * @return
	 */
	@Transactional
	public int updateAllocation(int memberId, Double percentage) {
		return memberRepository.updateAllocation(percentage, memberId);
	}
}
