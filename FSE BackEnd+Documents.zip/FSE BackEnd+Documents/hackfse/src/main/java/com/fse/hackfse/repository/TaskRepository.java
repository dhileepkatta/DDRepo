package com.fse.hackfse.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fse.hackfse.pojo.TaskDetail;

public interface TaskRepository extends JpaRepository<TaskDetail, Integer> {

List<TaskDetail> findByMemberId(int id);
}
