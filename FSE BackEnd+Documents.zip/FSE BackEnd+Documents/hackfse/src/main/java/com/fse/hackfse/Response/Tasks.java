package com.fse.hackfse.Response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;

@JsonInclude(Include.NON_NULL)
public class Tasks {
	
	private MemberDetail memberDetail;
	private List<TaskDetail> taskDetail;
	
	
	public MemberDetail getMemberDetail() {
		return memberDetail;
	}
	public void setMemberDetail(MemberDetail memberDetail) {
		this.memberDetail = memberDetail;
	}
	public List<TaskDetail> getTaskDetail() {
		return taskDetail;
	}
	public void setTaskDetail(List<TaskDetail> taskDetail) {
		this.taskDetail = taskDetail;
	}
	
	
	
	

}
