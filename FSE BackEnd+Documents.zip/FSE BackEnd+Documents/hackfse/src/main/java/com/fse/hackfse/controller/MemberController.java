package com.fse.hackfse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fse.hackfse.Response.MemberResponse;
import com.fse.hackfse.Response.ResponseHandler;
import com.fse.hackfse.Response.Tasks;
import com.fse.hackfse.constant.FseConstants;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.fse.hackfse.service.KafkaSender;
import com.fse.hackfse.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Autowired
	MemberService service;

	@Autowired
	KafkaSender kafka;

	@GetMapping("/list/{memberId}/taskDetails")
	@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
	public ResponseEntity<Object> getAssignedTasks(@PathVariable int memberId) {
		logger.info("::: Inside getAssignedTasks");
		MemberResponse memberResp = new MemberResponse();
		MemberDetail memberDetail = service.getMemberById(memberId);
		if (null != memberDetail) {
			List<TaskDetail> taskDetail = null;
			taskDetail = service.getAllTasks(memberId);
			Tasks tasks = new Tasks();
			tasks.setTaskDetail(taskDetail);
			tasks.setMemberDetail(memberDetail);
			memberResp.setTasks(tasks);
			kafka.send("---Retrieving the tasks  US-4 -----");
			kafka.send("Member name:  :  " + memberDetail.getMemberName());
			return ResponseHandler.generateResponse(FseConstants.RETR_SUCCESS, HttpStatus.OK, memberResp);

		} else {
			logger.info("::: No Records Found:::");
			return ResponseHandler.generateResponse(FseConstants.NO_RECORDS, HttpStatus.OK, memberResp);
		}

	}

}
