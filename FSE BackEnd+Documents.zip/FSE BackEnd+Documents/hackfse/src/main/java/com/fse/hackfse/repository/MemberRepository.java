package com.fse.hackfse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fse.hackfse.pojo.MemberDetail;

public interface MemberRepository extends JpaRepository<MemberDetail, Integer> {

	MemberDetail findByMemberId(int id);
	
	@Query("select case when count(c) >0 then true else false end from MemberDetail c where c.memberId =(:memberId)")
	boolean memberIdExist(@Param("memberId") int memberId);
	
	@Modifying
	@Query("update MemberDetail c set c.percentage =(:percentage) where c.memberId= (:memberId)")
	int updateAllocation(@Param("percentage") Double percentage, @Param("memberId") int memberId);
}
