package com.fse.hackfse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fse.hackfse.Response.MemberResponse;
import com.fse.hackfse.Response.ResponseHandler;
import com.fse.hackfse.constant.FseConstants;
import com.fse.hackfse.exception.MemberException;
import com.fse.hackfse.model.Member;
import com.fse.hackfse.model.Task;
import com.fse.hackfse.pojo.MemberDetail;
import com.fse.hackfse.pojo.TaskDetail;
import com.fse.hackfse.service.KafkaSender;
import com.fse.hackfse.service.MemberService;

@Controller
@RequestMapping("/manager")
public class ManagerController {

	private static final Logger logger = LoggerFactory.getLogger(ManagerController.class);

	@Autowired
	MemberService service;

	@Autowired
	KafkaSender kafka;

	/**
	 * method to add a member
	 * 
	 * @param member
	 * @return
	 */
	@PostMapping("/add-member")
	public ResponseEntity<Object> saveMember(@RequestBody Member member) {
		logger.info("::: Inside save Member method");
		ResponseHandler handler = null;
		Boolean isValid = true;
		String errorMessage = null;
		MemberDetail memberDetail = new MemberDetail();
		boolean isData = service.findByMemberId(member.getMemberId());
		if (isData) {
			errorMessage = FseConstants.MEMBER_EXISTS;
			isValid = false;
		}
		if (member.getExperience() <= 3) {

			errorMessage = "Experience should be greate than 3";
			isValid = false;
		}
		String[] skillArray = member.getSkills().split(",");
		if (skillArray.length < 3) {
			errorMessage = "Member should have atlease 3 skill sets";
			isValid = false;
		}
		if (member.getProjectEndDate().compareTo(member.getProjectStartDate()) < 0) {
			errorMessage = "Project End Date should be greater than Project Start Date";
			isValid = false;

		}
		if (!isValid) {
			logger.info("::: Validation Failed. ");
			return ResponseHandler.generateErrorResponse(errorMessage, HttpStatus.NOT_ACCEPTABLE);
		} else {
			logger.info("::: Calling Save method. ");
			BeanUtils.copyProperties(member, memberDetail);
			service.saveMemberDetails(memberDetail);
		}
		return ResponseHandler.generateResponse(FseConstants.ADD_SUCCESS, HttpStatus.OK, null);
	}

	/**
	 * method to getAllMembers
	 * 
	 * @return
	 */
	@GetMapping("/list/memberDetails")
	public ResponseEntity<Object> getAllMembers() {
		logger.info("Inside  getAllMembers method");
		ResponseHandler handler = null;
		MemberResponse memberResp = new MemberResponse();
		List<MemberDetail> memberList = null;
		memberList = service.getAllMembers();
		if (null != memberList && memberList.size() > 0) {
			logger.info("Method getAllMembers ::: Record Count:: " + memberList.size());
			memberResp.setMemberList(memberList);
			memberResp.setMemberListSize(memberList.size());
			return ResponseHandler.generateResponse(FseConstants.RETR_SUCCESS, HttpStatus.OK, memberResp);
		} else {
			logger.info("Method getAllMembers ::: No Records Found");
			return ResponseHandler.generateResponse(FseConstants.NO_RECORDS, HttpStatus.OK, memberResp);
		}

	}

	@PostMapping("/assign-task")
	public ResponseEntity<Object> assignTask(@RequestBody Task task) {
		logger.info("Inside assignTask method");
		ResponseHandler handler = null;
		Boolean isValid = true;
		MemberDetail memberDetail = service.getMemberById(task.getMemberId());
		if (null != memberDetail) {
			if (task.getTaskEndDate().compareTo(task.getTaskStartDate()) < 0) {
				isValid = false;
			}
			if (task.getTaskEndDate().compareTo(memberDetail.getProjectEndDate()) > 0) {
				isValid = false;
			}
			if (!isValid) {
				return ResponseHandler.generateErrorResponse("invalid dates", HttpStatus.NOT_ACCEPTABLE);
			}
			task.setMemberName(memberDetail.getMemberName());
			task.setMemberId(memberDetail.getMemberId());
			task.setMemberDetailId(memberDetail.getMemberDetailId());
			TaskDetail taskdetails = new TaskDetail();
			BeanUtils.copyProperties(task, taskdetails);
			generateKafkaMessage(memberDetail, taskdetails);
			return ResponseHandler.generateResponse(FseConstants.ADD_SUCCESS, HttpStatus.OK, null);
		} else {
			logger.info(" Searched member not Found:::");
			throw new MemberException("Member Not Found exception");
		}
	}

	private void generateKafkaMessage(MemberDetail memberDetail, TaskDetail taskdetails) {
		kafka.send("Task assigned to member-  :  " + memberDetail.getMemberId());
		kafka.send("Member name:  :  " + memberDetail.getMemberName());
		kafka.send("Added Task  :  " + taskdetails.getTaskName());
		service.assignTask(taskdetails);
	}

	/**
	 * method UpdateAllocation
	 * 
	 * @param member
	 * @return
	 */
	@PostMapping("/update")
	public ResponseEntity<Object> UpdateAllocation(@RequestBody Member member) {
		logger.info("::: Inside UpdateAllocation method");
		ResponseHandler handler = null;
		MemberDetail memberDetail = service.getMemberById(member.getMemberId());
		if (null != memberDetail) {
			java.util.Date d1 = new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(d1.getTime());
			if (memberDetail.getProjectEndDate().compareTo(sqlDate) > 0) {
				service.updateAllocation(memberDetail.getMemberId(), 100.0);
			} else {

				service.updateAllocation(memberDetail.getMemberId(), 0.0);
			}
			return ResponseHandler.generateResponse(FseConstants.ADD_SUCCESS, HttpStatus.OK, null);

		} else {
			throw new MemberException("Member Not Found exception");
		}

	}

}
