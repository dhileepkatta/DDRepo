package com.fse.hackfse.constant;

public final class FseConstants {
	
	public static final  String RETR_SUCCESS ="Retrieved Successfully";
	public static final  String NO_RECORDS = "No records Found";
	public static final String MEMBER_EXISTS ="Member Id already exists";
	public static final String ADD_SUCCESS = "Successfully added.";
	

}
