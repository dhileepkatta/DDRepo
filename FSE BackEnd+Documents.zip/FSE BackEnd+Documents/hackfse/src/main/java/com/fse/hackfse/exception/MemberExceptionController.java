package com.fse.hackfse.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class MemberExceptionController {
	@ExceptionHandler(value = MemberException.class)
	   public ResponseEntity<Object> exception(MemberException exception) {
	      return new ResponseEntity<>("Member not found", HttpStatus.NOT_FOUND);
	   }
}
