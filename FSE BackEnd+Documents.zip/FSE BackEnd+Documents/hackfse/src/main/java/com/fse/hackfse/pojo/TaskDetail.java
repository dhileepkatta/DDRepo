package com.fse.hackfse.pojo;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "taskdetails")
public class TaskDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int taskId;
	private int memberDetailId;
	private String taskName;
	private int memberId;
	private String memberName;
	private String deliverables;

	private Date taskStartDate;
	private Date taskEndDate;

	public TaskDetail() {
		// default constructor
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getDeliverables() {
		return deliverables;
	}

	public void setDeliverables(String deliverables) {
		this.deliverables = deliverables;
	}

	public Date getTaskStartDate() {
		return taskStartDate;
	}

	public void setTaskStartDate(Date taskStartDate) {
		this.taskStartDate = taskStartDate;
	}

	public Date getTaskEndDate() {
		return taskEndDate;
	}

	public void setTaskEndDate(Date taskEndDate) {
		this.taskEndDate = taskEndDate;
	}

	public int getMemberDetailId() {
		return memberDetailId;
	}

	public void setMemberDetailId(int memberDetailId) {
		this.memberDetailId = memberDetailId;
	}
	
	

}
