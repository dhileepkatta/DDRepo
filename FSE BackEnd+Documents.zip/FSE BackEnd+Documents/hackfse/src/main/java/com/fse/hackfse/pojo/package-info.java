/**
 * 
 */
/**
 * @author cogjava2938
 *
 */
package com.fse.hackfse.pojo;