package com.fse.hackfse.Response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fse.hackfse.pojo.MemberDetail;

@JsonInclude(Include.NON_NULL)
public class MemberResponse {
	
	private List<MemberDetail> memberList;
	
	private int memberListSize;
	
	private Tasks tasks;

	public List<MemberDetail> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<MemberDetail> memberList) {
		this.memberList = memberList;
	}

	public int getMemberListSize() {
		return memberListSize;
	}

	public void setMemberListSize(int memberListSize) {
		this.memberListSize = memberListSize;
	}

	public Tasks getTasks() {
		return tasks;
	}

	public void setTasks(Tasks tasks) {
		this.tasks = tasks;
	}
	
	
	
	

}
