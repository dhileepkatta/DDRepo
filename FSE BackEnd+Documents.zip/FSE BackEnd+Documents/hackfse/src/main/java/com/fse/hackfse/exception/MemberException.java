package com.fse.hackfse.exception;

public class MemberException  extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	
	public MemberException() {
		super();
	}
	
	public MemberException(String message) {
		super(message);
	}
	

}
